@echo off
setlocal
where emcc >nul 2>nul
if errorlevel 1 (
  echo Emscripten was not found.
  echo Install the Emscripten SDK, activate it, then run this file again.
  pause
  exit /b 1
)
emcc portfolio.cpp -O3 -s WASM=1 -s MODULARIZE=1 -s EXPORT_NAME=PortfolioCore -s EXPORTED_FUNCTIONS=["_scroll_step"] -s EXPORTED_RUNTIME_METHODS=["ccall"] -o portfolio_core.js
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo C++ WebAssembly build complete.
echo Open index.html in a local web server to use the C++ animation.
pause
