#include <emscripten.h>

// C++ controls the automatic scroll speed.
// The HTML page asks this function for the number of pixels to scroll
// on each animation frame. The speed is intentionally gentle.
extern "C" {
    EMSCRIPTEN_KEEPALIVE
    double scroll_step(double delta_ms) {
        if (delta_ms < 0.0) delta_ms = 0.0;
        if (delta_ms > 40.0) delta_ms = 40.0;
        const double pixels_per_millisecond = 0.018;
        return delta_ms * pixels_per_millisecond;
    }
}
