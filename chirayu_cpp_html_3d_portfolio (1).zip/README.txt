# Chirayu Vijay — C++ + HTML 3D Portfolio

## What's included
- `index.html` — the portfolio design, 3D hover effects, animated background, screenshots, and automatic downward tour.
- `portfolio.cpp` — C++ code that calculates the automatic scroll movement.
- `build_cpp_wasm.bat` — builds the C++ file into WebAssembly using Emscripten.

## Run it immediately
1. Open `index.html` in Chrome.
2. The portfolio works straight away. Until the C++ WebAssembly file is built, it uses a JavaScript fallback for the automatic scroll.

## Enable the C++ part
Browsers cannot run a `.cpp` file directly. C++ must first be compiled to WebAssembly (`.wasm`) so the HTML page can call it.

1. Install the Emscripten SDK: https://emscripten.org/docs/getting_started/downloads.html
2. Open the Emscripten command prompt / activate the Emscripten environment.
3. Put all project files in the same folder.
4. Run `build_cpp_wasm.bat`.
5. Serve the folder locally (for example, with VS Code Live Server) and open `index.html`.

The build creates `portfolio_core.js` and `portfolio_core.wasm`. Keep both beside `index.html`.

## Personalization
The contact button is already set to `chirayuvijay13@gmail.com`.
The five supplied portfolio screenshots are embedded inside `index.html`, so you do not need to keep separate image files.
